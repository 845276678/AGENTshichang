// Health check route
